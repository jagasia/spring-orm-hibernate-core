package com.cts.hibernate.demo.jf003_hibernate_1;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.hibernate.demo.jf003_hibernate_1.model.Engineer;
import com.cts.hibernate.demo.jf003_hibernate_1.model.EngineerDao;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        //how to obtain a bean instance from spring IOC container
        ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("bean.xml");
        EngineerDao edao=(EngineerDao) ctx.getBean("edao");
        edao.create(new Engineer(null, "Jag", "India", "India"));
        List<Engineer> engineers = edao.read();
        for(Engineer e:engineers)
        	System.out.println(e);
        System.out.println("Done");
    }
}
