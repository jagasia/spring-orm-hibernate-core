package com.cts.hibernate.demo.jf003_hibernate_1.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

public class EngineerDao {
	private HibernateTemplate ht;

	public HibernateTemplate getHt() {
		return ht;
	}

	public void setHt(HibernateTemplate ht) {
		this.ht = ht;
	}
	@Transactional
	public Serializable create(Engineer engineer) 
	{
		return ht.save(engineer);
	}
	public List<Engineer> read() 
	{
		return ht.loadAll(Engineer.class);
	}
	public Engineer read(Long engineerId) 
	{
		return ht.load(Engineer.class, engineerId);
	}
	@Transactional
	public void update(Engineer engineer) 
	{
		ht.update(engineer);
	}
	@Transactional
	public void delete(Long engineerId) 
	{
		ht.delete(read(engineerId));
	}
	
}
