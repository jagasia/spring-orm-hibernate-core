package com.cts.hibernate1.hibernate_demo_2;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;

public class BranchDaoImpl {

	private HibernateTemplate ht;
	
	
	
	public HibernateTemplate getHt() {
		return ht;
	}
	public void setHt(HibernateTemplate ht) {
		this.ht = ht;
	}
	public Branch create(Branch branch) {
		return (Branch) ht.save("Branch", branch);
	}
	public List<Branch> read() {
		return ht.loadAll(Branch.class);
	}
	public Branch read(String bid) {
		return ht.get(Branch.class, bid);
	}
	public Serializable update(Branch branch) {
		return ht.save(branch);
	}
	public void delete(String bid) {
		ht.delete(read(bid));
	}
	
}
