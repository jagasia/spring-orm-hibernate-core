package com.cts.hibernate1.hibernate_demo_2;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
//        AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext("applicationContext.xml");
        
        BranchDaoImpl bdao=(BranchDaoImpl) ctx.getBean("bdao");
        List<Branch> branches = bdao.read();
        System.out.println("There are "+branches.size()+" records");
        for(Branch b : branches)
        	System.out.println(b);
        System.out.println("Done");
    }
}
